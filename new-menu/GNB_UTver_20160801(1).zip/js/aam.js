
var host = location.hostname;
if (host.indexOf('devus') != -1 || host.indexOf('devwww') != -1
|| host.indexOf('dev') != -1
|| host.indexOf('stgwww') != -1
|| host.indexOf('stgapp') != -1
|| host.indexOf('prod') != -1
|| host.indexOf('local') != -1) {
document.write(unescape("%3Cscript src='//tags.tiqcdn.com/utag/samsung/main/dev/utag.sync.js' type='text/javascript'%3E%3C/script%3E"));
} else if(host.indexOf('stgweb') != -1) {
document.write(unescape("%3Cscript src='//tags.tiqcdn.com/utag/samsung/main/qa/utag.sync.js' type='text/javascript'%3E%3C/script%3E"));
} else {
document.write(unescape("%3Cscript src='//tags.tiqcdn.com/utag/samsung/main/prod/utag.sync.js' type='text/javascript'%3E%3C/script%3E"));
}